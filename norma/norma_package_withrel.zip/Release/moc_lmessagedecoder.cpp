/****************************************************************************
** Meta object code from reading C++ file 'lmessagedecoder.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../Norma/lmessagedecoder.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'lmessagedecoder.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_LMessageDecoder_t {
    QByteArrayData data[39];
    char stringdata[449];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_LMessageDecoder_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_LMessageDecoder_t qt_meta_stringdata_LMessageDecoder = {
    {
QT_MOC_LITERAL(0, 0, 15),
QT_MOC_LITERAL(1, 16, 15),
QT_MOC_LITERAL(2, 32, 0),
QT_MOC_LITERAL(3, 33, 19),
QT_MOC_LITERAL(4, 53, 7),
QT_MOC_LITERAL(5, 61, 5),
QT_MOC_LITERAL(6, 67, 8),
QT_MOC_LITERAL(7, 76, 15),
QT_MOC_LITERAL(8, 92, 11),
QT_MOC_LITERAL(9, 104, 10),
QT_MOC_LITERAL(10, 115, 8),
QT_MOC_LITERAL(11, 124, 16),
QT_MOC_LITERAL(12, 141, 15),
QT_MOC_LITERAL(13, 157, 14),
QT_MOC_LITERAL(14, 172, 13),
QT_MOC_LITERAL(15, 186, 8),
QT_MOC_LITERAL(16, 195, 11),
QT_MOC_LITERAL(17, 207, 10),
QT_MOC_LITERAL(18, 218, 11),
QT_MOC_LITERAL(19, 230, 5),
QT_MOC_LITERAL(20, 236, 5),
QT_MOC_LITERAL(21, 242, 8),
QT_MOC_LITERAL(22, 251, 20),
QT_MOC_LITERAL(23, 272, 4),
QT_MOC_LITERAL(24, 277, 12),
QT_MOC_LITERAL(25, 290, 8),
QT_MOC_LITERAL(26, 299, 8),
QT_MOC_LITERAL(27, 308, 5),
QT_MOC_LITERAL(28, 314, 12),
QT_MOC_LITERAL(29, 327, 14),
QT_MOC_LITERAL(30, 342, 11),
QT_MOC_LITERAL(31, 354, 7),
QT_MOC_LITERAL(32, 362, 10),
QT_MOC_LITERAL(33, 373, 25),
QT_MOC_LITERAL(34, 399, 3),
QT_MOC_LITERAL(35, 403, 6),
QT_MOC_LITERAL(36, 410, 11),
QT_MOC_LITERAL(37, 422, 5),
QT_MOC_LITERAL(38, 428, 20)
    },
    "LMessageDecoder\0ErrorCompletion\0\0"
    "ECommandMessageType\0msgType\0msgID\0"
    "complete\0ErrorLLRPStatus\0EStatusCode\0"
    "statuscode\0QString*\0errorDescription\0"
    "ErrorParamField\0EParameterType\0"
    "ParameterType\0FieldNum\0Fstatuscode\0"
    "ErrorField\0DeviceError\0error\0ecode\0"
    "Response\0EResponseMessageType\0type\0"
    "QJsonObject*\0jsObject\0AliveMsg\0value\0"
    "FactoryReset\0decodedMessage\0messageType\0"
    "Closing\0setVersion\0ESupportedProtocolVersion\0"
    "ver\0decode\0QByteArray*\0pdata\0"
    "backToDefaultVersion"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_LMessageDecoder[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      12,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    3,   84,    2, 0x06 /* Public */,
       7,    4,   91,    2, 0x06 /* Public */,
      12,    6,  100,    2, 0x06 /* Public */,
      17,    4,  113,    2, 0x06 /* Public */,
      18,    1,  122,    2, 0x06 /* Public */,
      19,    1,  125,    2, 0x06 /* Public */,
      21,    2,  128,    2, 0x06 /* Public */,
      26,    1,  133,    2, 0x06 /* Public */,
      28,    0,  136,    2, 0x06 /* Public */,
      29,    2,  137,    2, 0x06 /* Public */,
      31,    1,  142,    2, 0x06 /* Public */,
      32,    1,  145,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      35,    1,  148,    2, 0x0a /* Public */,
      38,    0,  151,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3, QMetaType::UInt, QMetaType::Bool,    4,    5,    6,
    QMetaType::Void, 0x80000000 | 3, QMetaType::UInt, 0x80000000 | 8, 0x80000000 | 10,    4,    5,    9,   11,
    QMetaType::Void, 0x80000000 | 3, QMetaType::UInt, 0x80000000 | 13, 0x80000000 | 8, QMetaType::UShort, 0x80000000 | 8,    4,    5,   14,    9,   15,   16,
    QMetaType::Void, 0x80000000 | 3, QMetaType::UInt, QMetaType::UShort, 0x80000000 | 8,    4,    5,   15,   16,
    QMetaType::Void, 0x80000000 | 10,   11,
    QMetaType::Void, 0x80000000 | 8,   20,
    QMetaType::Void, 0x80000000 | 22, 0x80000000 | 24,   23,   25,
    QMetaType::Void, QMetaType::UInt,   27,
    QMetaType::Void,
    QMetaType::Void, QMetaType::UShort, 0x80000000 | 24,   30,   25,
    QMetaType::Void, QMetaType::UInt,    5,
    QMetaType::Void, 0x80000000 | 33,   34,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 36,   37,
    QMetaType::Void,

       0        // eod
};

void LMessageDecoder::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        LMessageDecoder *_t = static_cast<LMessageDecoder *>(_o);
        switch (_id) {
        case 0: _t->ErrorCompletion((*reinterpret_cast< ECommandMessageType(*)>(_a[1])),(*reinterpret_cast< quint32(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3]))); break;
        case 1: _t->ErrorLLRPStatus((*reinterpret_cast< ECommandMessageType(*)>(_a[1])),(*reinterpret_cast< quint32(*)>(_a[2])),(*reinterpret_cast< EStatusCode(*)>(_a[3])),(*reinterpret_cast< QString*(*)>(_a[4]))); break;
        case 2: _t->ErrorParamField((*reinterpret_cast< ECommandMessageType(*)>(_a[1])),(*reinterpret_cast< quint32(*)>(_a[2])),(*reinterpret_cast< EParameterType(*)>(_a[3])),(*reinterpret_cast< EStatusCode(*)>(_a[4])),(*reinterpret_cast< quint16(*)>(_a[5])),(*reinterpret_cast< EStatusCode(*)>(_a[6]))); break;
        case 3: _t->ErrorField((*reinterpret_cast< ECommandMessageType(*)>(_a[1])),(*reinterpret_cast< quint32(*)>(_a[2])),(*reinterpret_cast< quint16(*)>(_a[3])),(*reinterpret_cast< EStatusCode(*)>(_a[4]))); break;
        case 4: _t->DeviceError((*reinterpret_cast< QString*(*)>(_a[1]))); break;
        case 5: _t->error((*reinterpret_cast< EStatusCode(*)>(_a[1]))); break;
        case 6: _t->Response((*reinterpret_cast< EResponseMessageType(*)>(_a[1])),(*reinterpret_cast< QJsonObject*(*)>(_a[2]))); break;
        case 7: _t->AliveMsg((*reinterpret_cast< quint32(*)>(_a[1]))); break;
        case 8: _t->FactoryReset(); break;
        case 9: _t->decodedMessage((*reinterpret_cast< quint16(*)>(_a[1])),(*reinterpret_cast< QJsonObject*(*)>(_a[2]))); break;
        case 10: _t->Closing((*reinterpret_cast< quint32(*)>(_a[1]))); break;
        case 11: _t->setVersion((*reinterpret_cast< ESupportedProtocolVersion(*)>(_a[1]))); break;
        case 12: _t->decode((*reinterpret_cast< QByteArray*(*)>(_a[1]))); break;
        case 13: _t->backToDefaultVersion(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (LMessageDecoder::*_t)(ECommandMessageType , quint32 , bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&LMessageDecoder::ErrorCompletion)) {
                *result = 0;
            }
        }
        {
            typedef void (LMessageDecoder::*_t)(ECommandMessageType , quint32 , EStatusCode , QString * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&LMessageDecoder::ErrorLLRPStatus)) {
                *result = 1;
            }
        }
        {
            typedef void (LMessageDecoder::*_t)(ECommandMessageType , quint32 , EParameterType , EStatusCode , quint16 , EStatusCode );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&LMessageDecoder::ErrorParamField)) {
                *result = 2;
            }
        }
        {
            typedef void (LMessageDecoder::*_t)(ECommandMessageType , quint32 , quint16 , EStatusCode );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&LMessageDecoder::ErrorField)) {
                *result = 3;
            }
        }
        {
            typedef void (LMessageDecoder::*_t)(QString * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&LMessageDecoder::DeviceError)) {
                *result = 4;
            }
        }
        {
            typedef void (LMessageDecoder::*_t)(EStatusCode );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&LMessageDecoder::error)) {
                *result = 5;
            }
        }
        {
            typedef void (LMessageDecoder::*_t)(EResponseMessageType , QJsonObject * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&LMessageDecoder::Response)) {
                *result = 6;
            }
        }
        {
            typedef void (LMessageDecoder::*_t)(quint32 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&LMessageDecoder::AliveMsg)) {
                *result = 7;
            }
        }
        {
            typedef void (LMessageDecoder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&LMessageDecoder::FactoryReset)) {
                *result = 8;
            }
        }
        {
            typedef void (LMessageDecoder::*_t)(quint16 , QJsonObject * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&LMessageDecoder::decodedMessage)) {
                *result = 9;
            }
        }
        {
            typedef void (LMessageDecoder::*_t)(quint32 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&LMessageDecoder::Closing)) {
                *result = 10;
            }
        }
        {
            typedef void (LMessageDecoder::*_t)(ESupportedProtocolVersion );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&LMessageDecoder::setVersion)) {
                *result = 11;
            }
        }
    }
}

const QMetaObject LMessageDecoder::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_LMessageDecoder.data,
      qt_meta_data_LMessageDecoder,  qt_static_metacall, 0, 0}
};


const QMetaObject *LMessageDecoder::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *LMessageDecoder::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_LMessageDecoder.stringdata))
        return static_cast<void*>(const_cast< LMessageDecoder*>(this));
    return QObject::qt_metacast(_clname);
}

int LMessageDecoder::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 14)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 14;
    }
    return _id;
}

// SIGNAL 0
void LMessageDecoder::ErrorCompletion(ECommandMessageType _t1, quint32 _t2, bool _t3)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void LMessageDecoder::ErrorLLRPStatus(ECommandMessageType _t1, quint32 _t2, EStatusCode _t3, QString * _t4)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void LMessageDecoder::ErrorParamField(ECommandMessageType _t1, quint32 _t2, EParameterType _t3, EStatusCode _t4, quint16 _t5, EStatusCode _t6)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)), const_cast<void*>(reinterpret_cast<const void*>(&_t5)), const_cast<void*>(reinterpret_cast<const void*>(&_t6)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void LMessageDecoder::ErrorField(ECommandMessageType _t1, quint32 _t2, quint16 _t3, EStatusCode _t4)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void LMessageDecoder::DeviceError(QString * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void LMessageDecoder::error(EStatusCode _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void LMessageDecoder::Response(EResponseMessageType _t1, QJsonObject * _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void LMessageDecoder::AliveMsg(quint32 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void LMessageDecoder::FactoryReset()
{
    QMetaObject::activate(this, &staticMetaObject, 8, 0);
}

// SIGNAL 9
void LMessageDecoder::decodedMessage(quint16 _t1, QJsonObject * _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void LMessageDecoder::Closing(quint32 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void LMessageDecoder::setVersion(ESupportedProtocolVersion _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}
QT_END_MOC_NAMESPACE
