/****************************************************************************
** Meta object code from reading C++ file 'normamain.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../Norma/normamain.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'normamain.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_NormaMain_t {
    QByteArrayData data[52];
    char stringdata[668];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_NormaMain_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_NormaMain_t qt_meta_stringdata_NormaMain = {
    {
QT_MOC_LITERAL(0, 0, 9),
QT_MOC_LITERAL(1, 10, 13),
QT_MOC_LITERAL(2, 24, 0),
QT_MOC_LITERAL(3, 25, 4),
QT_MOC_LITERAL(4, 30, 29),
QT_MOC_LITERAL(5, 60, 15),
QT_MOC_LITERAL(6, 76, 8),
QT_MOC_LITERAL(7, 85, 18),
QT_MOC_LITERAL(8, 104, 14),
QT_MOC_LITERAL(9, 119, 5),
QT_MOC_LITERAL(10, 125, 17),
QT_MOC_LITERAL(11, 143, 14),
QT_MOC_LITERAL(12, 158, 5),
QT_MOC_LITERAL(13, 164, 20),
QT_MOC_LITERAL(14, 185, 4),
QT_MOC_LITERAL(15, 190, 9),
QT_MOC_LITERAL(16, 200, 20),
QT_MOC_LITERAL(17, 221, 18),
QT_MOC_LITERAL(18, 240, 12),
QT_MOC_LITERAL(19, 253, 17),
QT_MOC_LITERAL(20, 271, 8),
QT_MOC_LITERAL(21, 280, 15),
QT_MOC_LITERAL(22, 296, 15),
QT_MOC_LITERAL(23, 312, 13),
QT_MOC_LITERAL(24, 326, 20),
QT_MOC_LITERAL(25, 347, 7),
QT_MOC_LITERAL(26, 355, 12),
QT_MOC_LITERAL(27, 368, 8),
QT_MOC_LITERAL(28, 377, 9),
QT_MOC_LITERAL(29, 387, 3),
QT_MOC_LITERAL(30, 391, 20),
QT_MOC_LITERAL(31, 412, 13),
QT_MOC_LITERAL(32, 426, 11),
QT_MOC_LITERAL(33, 438, 11),
QT_MOC_LITERAL(34, 450, 17),
QT_MOC_LITERAL(35, 468, 5),
QT_MOC_LITERAL(36, 474, 13),
QT_MOC_LITERAL(37, 488, 13),
QT_MOC_LITERAL(38, 502, 12),
QT_MOC_LITERAL(39, 515, 6),
QT_MOC_LITERAL(40, 522, 7),
QT_MOC_LITERAL(41, 530, 9),
QT_MOC_LITERAL(42, 540, 12),
QT_MOC_LITERAL(43, 553, 17),
QT_MOC_LITERAL(44, 571, 18),
QT_MOC_LITERAL(45, 590, 4),
QT_MOC_LITERAL(46, 595, 8),
QT_MOC_LITERAL(47, 604, 6),
QT_MOC_LITERAL(48, 611, 9),
QT_MOC_LITERAL(49, 621, 12),
QT_MOC_LITERAL(50, 634, 25),
QT_MOC_LITERAL(51, 660, 7)
    },
    "NormaMain\0writeToClient\0\0data\0"
    "SetDecoderBackToDefaultVesion\0"
    "closeConnection\0readerOK\0forceStopOperation\0"
    "setReaderState\0state\0newReaderInitials\0"
    "NormaIdentity*\0newID\0instanceReaderStatus\0"
    "name\0connected\0instanceClientStatus\0"
    "updateInstanceInfo\0thisInstance\0"
    "updateDeviceError\0errorStr\0updateLLRPError\0"
    "changeTLSstatus\0mainToEncoder\0"
    "EResponseMessageType\0msgtype\0QJsonObject*\0"
    "jsonData\0PrtclUsed\0ver\0handleConnectionInit\0"
    "ClientAddress\0handle_data\0QByteArray*\0"
    "keepaliveRequired\0value\0trigKeepalive\0"
    "stopKeepalive\0ReaderStatus\0status\0"
    "process\0forceIdle\0instanceName\0"
    "forceBackToActive\0handleErrorStrInfo\0"
    "type\0QString*\0errStr\0TLSstatus\0"
    "ProtocolUsed\0ESupportedProtocolVersion\0"
    "version"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_NormaMain[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      27,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      15,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  149,    2, 0x06 /* Public */,
       4,    0,  152,    2, 0x06 /* Public */,
       5,    0,  153,    2, 0x06 /* Public */,
       6,    0,  154,    2, 0x06 /* Public */,
       7,    0,  155,    2, 0x06 /* Public */,
       8,    1,  156,    2, 0x06 /* Public */,
      10,    1,  159,    2, 0x06 /* Public */,
      13,    2,  162,    2, 0x06 /* Public */,
      16,    2,  167,    2, 0x06 /* Public */,
      17,    1,  172,    2, 0x06 /* Public */,
      19,    2,  175,    2, 0x06 /* Public */,
      21,    2,  180,    2, 0x06 /* Public */,
      22,    1,  185,    2, 0x06 /* Public */,
      23,    2,  188,    2, 0x06 /* Public */,
      28,    1,  193,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      30,    1,  196,    2, 0x0a /* Public */,
      32,    1,  199,    2, 0x0a /* Public */,
      34,    1,  202,    2, 0x0a /* Public */,
      36,    0,  205,    2, 0x0a /* Public */,
      37,    0,  206,    2, 0x0a /* Public */,
      38,    1,  207,    2, 0x0a /* Public */,
      40,    0,  210,    2, 0x0a /* Public */,
      41,    1,  211,    2, 0x0a /* Public */,
      43,    2,  214,    2, 0x0a /* Public */,
      44,    2,  219,    2, 0x0a /* Public */,
      48,    1,  224,    2, 0x0a /* Public */,
      49,    1,  227,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QByteArray,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Void, 0x80000000 | 11,   12,
    QMetaType::Void, QMetaType::QString, QMetaType::Bool,   14,   15,
    QMetaType::Void, QMetaType::QString, QMetaType::Bool,   14,   15,
    QMetaType::Void, 0x80000000 | 11,   18,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   14,   20,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   14,   20,
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Void, 0x80000000 | 24, 0x80000000 | 26,   25,   27,
    QMetaType::Void, QMetaType::UChar,   29,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,   31,
    QMetaType::Void, 0x80000000 | 33,    3,
    QMetaType::Void, QMetaType::UInt,   35,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   39,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   42,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 11,   42,   12,
    QMetaType::Void, QMetaType::Bool, 0x80000000 | 46,   45,   47,
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Void, 0x80000000 | 50,   51,

       0        // eod
};

void NormaMain::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        NormaMain *_t = static_cast<NormaMain *>(_o);
        switch (_id) {
        case 0: _t->writeToClient((*reinterpret_cast< QByteArray(*)>(_a[1]))); break;
        case 1: _t->SetDecoderBackToDefaultVesion(); break;
        case 2: _t->closeConnection(); break;
        case 3: _t->readerOK(); break;
        case 4: _t->forceStopOperation(); break;
        case 5: _t->setReaderState((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 6: _t->newReaderInitials((*reinterpret_cast< NormaIdentity*(*)>(_a[1]))); break;
        case 7: _t->instanceReaderStatus((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 8: _t->instanceClientStatus((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 9: _t->updateInstanceInfo((*reinterpret_cast< NormaIdentity*(*)>(_a[1]))); break;
        case 10: _t->updateDeviceError((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 11: _t->updateLLRPError((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 12: _t->changeTLSstatus((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 13: _t->mainToEncoder((*reinterpret_cast< EResponseMessageType(*)>(_a[1])),(*reinterpret_cast< QJsonObject*(*)>(_a[2]))); break;
        case 14: _t->PrtclUsed((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 15: _t->handleConnectionInit((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 16: _t->handle_data((*reinterpret_cast< QByteArray*(*)>(_a[1]))); break;
        case 17: _t->keepaliveRequired((*reinterpret_cast< quint32(*)>(_a[1]))); break;
        case 18: _t->trigKeepalive(); break;
        case 19: _t->stopKeepalive(); break;
        case 20: _t->ReaderStatus((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 21: _t->process(); break;
        case 22: _t->forceIdle((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 23: _t->forceBackToActive((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< NormaIdentity*(*)>(_a[2]))); break;
        case 24: _t->handleErrorStrInfo((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< QString*(*)>(_a[2]))); break;
        case 25: _t->TLSstatus((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 26: _t->ProtocolUsed((*reinterpret_cast< ESupportedProtocolVersion(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (NormaMain::*_t)(QByteArray );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&NormaMain::writeToClient)) {
                *result = 0;
            }
        }
        {
            typedef void (NormaMain::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&NormaMain::SetDecoderBackToDefaultVesion)) {
                *result = 1;
            }
        }
        {
            typedef void (NormaMain::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&NormaMain::closeConnection)) {
                *result = 2;
            }
        }
        {
            typedef void (NormaMain::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&NormaMain::readerOK)) {
                *result = 3;
            }
        }
        {
            typedef void (NormaMain::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&NormaMain::forceStopOperation)) {
                *result = 4;
            }
        }
        {
            typedef void (NormaMain::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&NormaMain::setReaderState)) {
                *result = 5;
            }
        }
        {
            typedef void (NormaMain::*_t)(NormaIdentity * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&NormaMain::newReaderInitials)) {
                *result = 6;
            }
        }
        {
            typedef void (NormaMain::*_t)(QString , bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&NormaMain::instanceReaderStatus)) {
                *result = 7;
            }
        }
        {
            typedef void (NormaMain::*_t)(QString , bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&NormaMain::instanceClientStatus)) {
                *result = 8;
            }
        }
        {
            typedef void (NormaMain::*_t)(NormaIdentity * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&NormaMain::updateInstanceInfo)) {
                *result = 9;
            }
        }
        {
            typedef void (NormaMain::*_t)(QString , QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&NormaMain::updateDeviceError)) {
                *result = 10;
            }
        }
        {
            typedef void (NormaMain::*_t)(QString , QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&NormaMain::updateLLRPError)) {
                *result = 11;
            }
        }
        {
            typedef void (NormaMain::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&NormaMain::changeTLSstatus)) {
                *result = 12;
            }
        }
        {
            typedef void (NormaMain::*_t)(EResponseMessageType , QJsonObject * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&NormaMain::mainToEncoder)) {
                *result = 13;
            }
        }
        {
            typedef void (NormaMain::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&NormaMain::PrtclUsed)) {
                *result = 14;
            }
        }
    }
}

const QMetaObject NormaMain::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_NormaMain.data,
      qt_meta_data_NormaMain,  qt_static_metacall, 0, 0}
};


const QMetaObject *NormaMain::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *NormaMain::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_NormaMain.stringdata))
        return static_cast<void*>(const_cast< NormaMain*>(this));
    return QObject::qt_metacast(_clname);
}

int NormaMain::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 27)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 27;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 27)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 27;
    }
    return _id;
}

// SIGNAL 0
void NormaMain::writeToClient(QByteArray _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void NormaMain::SetDecoderBackToDefaultVesion()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void NormaMain::closeConnection()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}

// SIGNAL 3
void NormaMain::readerOK()
{
    QMetaObject::activate(this, &staticMetaObject, 3, 0);
}

// SIGNAL 4
void NormaMain::forceStopOperation()
{
    QMetaObject::activate(this, &staticMetaObject, 4, 0);
}

// SIGNAL 5
void NormaMain::setReaderState(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void NormaMain::newReaderInitials(NormaIdentity * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void NormaMain::instanceReaderStatus(QString _t1, bool _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void NormaMain::instanceClientStatus(QString _t1, bool _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void NormaMain::updateInstanceInfo(NormaIdentity * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void NormaMain::updateDeviceError(QString _t1, QString _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void NormaMain::updateLLRPError(QString _t1, QString _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void NormaMain::changeTLSstatus(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}

// SIGNAL 13
void NormaMain::mainToEncoder(EResponseMessageType _t1, QJsonObject * _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 13, _a);
}

// SIGNAL 14
void NormaMain::PrtclUsed(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 14, _a);
}
QT_END_MOC_NAMESPACE
